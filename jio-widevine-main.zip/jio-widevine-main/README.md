
<p align='center'><img src="https://castlabs.com/wp-content/uploads/widevine-logo.svg" width="120" ></p>

**The playlist works only on OTT Navigator.**


 **⚠️ login bypass** 

<h2>🍁 HOW TO USE : </h2>

### 🔐 Installation :

### 🅰️ First Download This Application ( PHP WEB SERVER )

1. `KSWEB PRO v3.987 for Mobile`

```

https://tsneh.vercel.app/ksweb_3.987.apk

```

2. `XAMPP for Windows (PC)`

```

https://www.apachefriends.org/download.html

```

### 🅱️ Then Download This Zip File


1. Locate & Extract all Files in LocalHost `Htdocs` Root Folder. </br>

2. Open KSWEB app & start the server. </br>

3. Now Open `jio-widevine` Below Link :

```

http://localhost:8080/jio-widevine/

```





</br>

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN OUR TELEGRAM CHANNEL

- https://t.me/jitendraunatti_github

</br>



## ▶️ PlayList Methods :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :

```

http://localhost:8080/jio-widevine

```

• Hurrah !! Now Play & Enjoy with your Jiotv Channels .

<h3>🚸 WARNINGS :</h3>

- This is Just For Educational Purpose
- I am in no way responsible if you misuse the code and cause revenue loss to the concerned parties and owners of the portal
- Don't Sell this Script, This is 💯% Free
<hr>

<h3>🤗 CONTACT US : </h3>

- TELEGRAM CHANNEL  JOIN NOW https://t.me/jitendraunatti_github
- FOR ANY QUERY CONTACT US ON [PROTON-MAIL](mailto:jitendraunatti@pm.me)

</br>
<hr>

<h3> ⚠️License and Disclosures : </hr>

This code is just a CASE STUDY on how the authentication mechanism and live streaming using IPTV works I am in no way responsible if you misuse the code and cause revenue loss to the concerned parties and owners of the portal
This code is protected under the [GPL](https://github.com/Jitendraunatti/STALKER-PORTAL/blob/main/LICENSE) license


<h4 align='center'>© 2021-24 JITENDRA KUMAR</h4>

<!-- DO NOT REMOVE THIS CREDIT -->
<!-- © 2021-24 jitendra kumar -->
